|description||
|---|---|
|keywords||
|dir-name||
|dir-name-en||
|tenant-type||
|machine-translation|en,ja-marker|
|slug|oceanbase-cdb_ob_spm_evo_result-sys-tenant|

# oceanbase.CDB_OB_SPM_EVO_RESULT

<main id="notice" type='explain'>
<h4>说明</h4>
<p>该视图从 V4.2.5 版本开始引入。</p>
</main>

## 功能描述

展示所有租户的 SPM 计划演进信息。

## 字段说明

| **字段** | **类型** | **是否为 NULL** | **描述** |
| --- | --- | --- | --- |
| TENANT_ID           | bigint(20)          | NO   |  租户 id。    |
| OWNER               | varchar(128) | NO   |    执行演进任务的用户。  |
| RECORD_TIME         | timestamp(6) | NO   |    记录演进结果的时间。  |
| SVR_IP              | varchar(46)  | NO   |    执行演进任务的 server ip。  |
| SVR_PORT            | bigint(20)   | NO   |    执行演进任务的 server port。 |
| SQL_ID              | varchar(32)  | NO   |    执行演进任务的 sql id。  |
| TYPE                | varchar(32)  | NO   |    记录的类型：<ul><li>`OnlineEvolve`：表示在线演进模式记录的是演进任务的结果，下面所有的字段仅当类型为当前值时才有效。</li><li>`FirstBaseline`：表示记录的是生成首个基线的 SQL。</li><li>`UnReproducible`： 表示记录的是当前 SQL 所有的基线都无法复现。</li><li>`BaselineFirst`：表示基线优先模式产生了新的计划，但是还原并使用了基线计划。</li><li>`BestBaseline`：表示产生并并使用了最优基线计划。</li><li>`FixedBaseline`：表示使用了固定基线计划。</li></ul> |
| START_TIME          | timestamp(6) | YES  |  演进任务开始的时间。    |
| END_TIME            | timestamp(6) | YES  |   演进任务结束的时间。   |
| STATUS              | varchar(7)   | YES  |   演进任务的状态：<ul><li>`success`：演进任务正常结束。</li><li>`timeout`：演进任务超时（此时根据演进期间的执行信息判断哪个计划更好）。   |
| NEW_PLAN_BETTER     | tinyint(4)   | YES  |   演进计划是否更优。   |
| EVO_PLAN_EXEC_COUNT | bigint(20)   | YES  |   演进期间演进计划的执行次数。   |
| EVO_PLAN_CPU_TIME   | bigint(20)   | YES  |   演进期间演进计划的平均 CPU 开销。   |
| BASELINE_EXEC_COUNT | bigint(20)   | YES  |   演进期间基线计划的执行次数。  |
| BASELINE_CPU_TIME   | bigint(20)   | YES  |   演进期间基线计划的平均 CPU 开销。   |

## 查询示例

系统租户下，查询所有租户的 SPM 计划演进信息。

```shell
obclient [oceanbase]> SELECT * FROM oceanbase.CDB_OB_SPM_EVO_RESULT;
```
