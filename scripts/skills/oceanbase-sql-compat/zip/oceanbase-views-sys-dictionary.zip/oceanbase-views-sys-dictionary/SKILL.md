---
name: oceanbase-views-sys-dictionary
description: Look up OceanBase 4.4.2 sys-tenant dictionary views.
type: prompt
whenToUse: When the user asks about a sys-tenant dictionary view (e.g., oceanbase.DBA_OB_*) in OceanBase.
---

# OceanBase Sys-Tenant Dictionary Views

Use the bundled docs to verify sys-tenant dictionary views in OceanBase 4.4.2.

## Resources

- `system-views/300.system-view-of-sys-tenant/200.dictionary-view-of-sys-tenant/`

## How to use

1. Grep for the view name under both language trees.
2. Read the matching file to get column definitions and descriptions.
3. Cite the doc file path in your answer.
