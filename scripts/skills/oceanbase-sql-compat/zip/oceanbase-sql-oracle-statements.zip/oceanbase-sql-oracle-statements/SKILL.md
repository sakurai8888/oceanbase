---
name: oceanbase-sql-oracle-statements
description: Look up OceanBase 4.4.2 Oracle-mode SQL statements (DDL, DML, DQL, DCL, TCL).
type: prompt
whenToUse: When the user asks about the syntax or compatibility of a specific Oracle-mode SQL statement in OceanBase.
---

# OceanBase Oracle-Mode SQL Statements

Use the bundled docs to verify Oracle-mode SQL statement syntax in OceanBase 4.4.2.

## Resources

- `sql-syntax/300.common-tenant-of-oracle-mode/900.sql-statement-of-oracle-mode/`

## How to use

1. Identify the statement name (e.g., CREATE TABLE, SELECT, INSERT, MERGE).
2. Grep for `<statement>-of-oracle-mode.md` in the statement directory.
3. Read the doc; compare its Syntax block against the user's SQL.
4. Classify as ✅ SUPPORTED, ⚠️ DIFFERENT, 🔧 REWRITE, ❌ UNSUPPORTED, or ❓ UNVERIFIED, with a doc citation.
