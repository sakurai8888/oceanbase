---
name: oceanbase-pl-oracle-language
description: Look up OceanBase 4.4.2 Oracle-mode PL/SQL language features: data types, process control, collections/records, static/dynamic SQL, stored subprograms, triggers, packages, exception handling, DDL operations.
type: prompt
whenToUse: When the user asks about Oracle-mode PL/SQL language constructs, stored procedures, functions, triggers, packages, or exception handling in OceanBase.
---

# OceanBase PL/Oracle Mode Language Reference

Use the bundled docs to verify Oracle-mode PL/SQL language features in OceanBase 4.4.2.

## Resources

- `pl-reference/300.pl-oracle/` excluding `1400.pl-system-package-oracle` and `1300.pl-label-security-package-oracle`.

Contains language basics, data types, process control, collections/records, static SQL, dynamic SQL, stored procedures/functions, triggers, packages, exception handling, DDL operations.

## How to use

1. Identify the PL/SQL construct or stored object.
2. Grep for the name under both language trees.
3. Read the matching file(s) and compare syntax/semantics.
4. Cite the doc file path for any compatibility issue.

For system packages, use the sibling skill `oceanbase-pl-oracle-packages`.
