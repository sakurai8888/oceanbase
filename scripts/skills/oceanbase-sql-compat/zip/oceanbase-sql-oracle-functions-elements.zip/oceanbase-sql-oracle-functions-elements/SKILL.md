---
name: oceanbase-sql-oracle-functions-elements
description: Look up OceanBase 4.4.2 Oracle-mode data types, operators, functions, expressions, conditions, pseudo columns, queries/subqueries, and DDL functions.
type: prompt
whenToUse: When the user asks about Oracle-mode SQL functions, operators, data types, pseudo columns, expressions, conditions, or DDL functions in OceanBase.
---

# OceanBase Oracle-Mode Functions & Language Elements

Use the bundled docs to verify Oracle-mode SQL language elements in OceanBase 4.4.2.

## Resources

- `sql-syntax/300.common-tenant-of-oracle-mode/300.basic-elements-of-oracle-mode/`
- `sql-syntax/300.common-tenant-of-oracle-mode/400.operator-of-oracle-mode/`
- `sql-syntax/300.common-tenant-of-oracle-mode/500.functions-of-oracle-mode/`
- `sql-syntax/300.common-tenant-of-oracle-mode/600.expression-of-oracle-mode/`
- `sql-syntax/300.common-tenant-of-oracle-mode/700.condition-of-oracle-mode/`
- `sql-syntax/300.common-tenant-of-oracle-mode/800.queries-and-subqueries-of-oracle-mode/`
- `sql-syntax/300.common-tenant-of-oracle-mode/1000.ddl-function-of-oracle-mode/`
- `sql-syntax/300.common-tenant-of-oracle-mode/200.pseudo-column-of-oracle-mode/`

## How to use

1. Identify the construct: data type, function, operator, expression, condition, pseudo column, query clause, or DDL function.
2. Grep for the construct name in the matching subdirectory.
3. Read the doc; compare against the user's SQL. Note OceanBase-specific deviations from Oracle.
4. Cite the doc file path when flagging differences or unsupported behavior.
