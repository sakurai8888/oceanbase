---
name: oceanbase-pl-mysql
description: Look up OceanBase 4.4.2 PL/SQL features in MySQL mode: stored objects, cursors, control statements, manipulation statements, system packages, exception handling, etc.
type: prompt
whenToUse: When the user asks about MySQL-mode stored procedures, functions, triggers, cursors, DBMS packages, or PL language features in OceanBase.
---

# OceanBase PL/MySQL Mode Reference

Use the bundled docs to verify PL/SQL features in OceanBase MySQL mode 4.4.2.

## Resources

- `pl-reference/200.pl-mysql/`

Contains:
- `100.basic-syntax-mysql.md`
- `200.storage-object-mysql/` — stored procedures/functions
- `300.cursor-mysql/`
- `400.control-statement-mysql/`
- `500.pl-manipulation-statement-mysql/`
- `600.sql-statements-for-pl-stored-programs-mysql/`
- `700.pl-database-management-statements-mysql/`
- `800.information-schema-dictionary-view-mysql/`
- `900.pl-exception-handling-statement-mysql/`
- `1000.pl-system-package-mysql/` — DBMS_* packages
- `1100.pl-reserved-keywords-mysql.md`

## How to use

1. Identify the PL object or package subprogram.
2. Grep for the name under both language trees.
3. Read the matching file(s) and compare signatures/syntax.
4. Cite the doc file path for any compatibility issue.
