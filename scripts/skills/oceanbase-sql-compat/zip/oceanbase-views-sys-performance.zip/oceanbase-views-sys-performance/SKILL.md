---
name: oceanbase-views-sys-performance
description: Look up OceanBase 4.4.2 sys-tenant performance views (GV$/V$).
type: prompt
whenToUse: When the user asks about a sys-tenant performance view (e.g., GV) in OceanBase.
---

# OceanBase Sys-Tenant Performance Views

Use the bundled docs to verify sys-tenant performance views in OceanBase 4.4.2.

## Resources

- `system-views/300.system-view-of-sys-tenant/300.performance-view-of-sys-tenant/`

## How to use

1. Grep for the view name under both language trees.
2. Read the matching file to get column definitions and descriptions.
3. Cite the doc file path in your answer.
