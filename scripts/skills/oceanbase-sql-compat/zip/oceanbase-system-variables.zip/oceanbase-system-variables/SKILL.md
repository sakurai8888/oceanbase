---
name: oceanbase-system-variables
description: Look up OceanBase 4.4.2 system variables (global and session variables such as sql_mode, ob_query_timeout, nls_*).
type: prompt
whenToUse: When the user asks about an OceanBase system variable, session variable, global variable, or SET statement behavior.
---

# OceanBase System Variables Reference

Use the bundled docs to answer questions about global and session system variables in OceanBase 4.4.2.

## Resources

- `references/en-US/configuration-items-and-system-variables/200.system-variable/`
- `references/zh-CN/configuration-items-and-system-variables/200.system-variable/`

Contains:
- `200.system-variable-overview.md`
- `300.global-system-variable/`
- `400.session-system-variable/`

## How to use

1. Grep for the variable name (case-insensitive) under both language trees.
2. Read the matching file(s). Note scope, default, valid values, and dynamic vs. read-only.
3. Quote the file path and relevant table in your answer.
4. If the variable is not found, say so and do not guess.
