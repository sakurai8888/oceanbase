---
name: oceanbase-views-mysql
description: Look up OceanBase 4.4.2 MySQL-mode dictionary and performance views, including information_schema and DBA_OB_* views.
type: prompt
whenToUse: When the user asks about a MySQL-mode system view, dictionary view, or performance view in OceanBase.
---

# OceanBase MySQL-Mode Views

Use the bundled docs to verify MySQL-mode views in OceanBase 4.4.2.

## Resources

- `system-views/400.system-view-of-mysql-mode/200.dictionary-view-of-mysql-mode/`
- `system-views/400.system-view-of-mysql-mode/300.performance-view-of-mysql-mode/`

## How to use

1. Grep for the view name under both language trees.
2. Read the matching file to get column definitions and descriptions.
3. Cite the doc file path in your answer.
