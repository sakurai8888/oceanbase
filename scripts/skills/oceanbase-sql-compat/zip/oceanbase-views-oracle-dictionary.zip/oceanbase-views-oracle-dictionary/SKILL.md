---
name: oceanbase-views-oracle-dictionary
description: Look up OceanBase 4.4.2 Oracle-mode dictionary views (DBA_*, ALL_*, USER_*).
type: prompt
whenToUse: When the user asks about an Oracle-mode dictionary view (e.g., DBA_TABLES) in OceanBase.
---

# OceanBase Oracle-Mode Dictionary Views

Use the bundled docs to verify Oracle-mode dictionary views in OceanBase 4.4.2.

## Resources

- `system-views/500.system-view-of-oracle-mode/200.dictionary-view-of-oracle-mode/`

## How to use

1. Grep for the view name under both language trees.
2. Read the matching file to get column definitions and descriptions.
3. Cite the doc file path in your answer.
