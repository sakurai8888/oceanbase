---
name: oceanbase-config-items
description: Look up OceanBase 4.4.2 cluster-level and tenant-level configuration items (parameters).
type: prompt
whenToUse: When the user asks about an OceanBase configuration item, tenant/cluster parameter, or `obconfig` / `_tenant_name` setting.
---

# OceanBase Configuration Items Reference

Use the bundled docs to answer questions about cluster-level and tenant-level configuration items in OceanBase 4.4.2.

## Resources

- `references/en-US/configuration-items-and-system-variables/100.system-configuration-items/`
- `references/zh-CN/configuration-items-and-system-variables/100.system-configuration-items/`

Both language trees contain:
- `200.system-configuration-items-overview-list.md`
- `300.cluster-level-configuration-items/`
- `400.tenant-level-configuration-items/`

## How to use

1. Grep for the parameter name (case-insensitive) under both language trees.
2. Read the matching file(s). The front-matter table lists scope, default value, value range, etc.
3. Quote the file path and the relevant parameter table in your answer.
4. If the parameter is not found, say so and do not guess.
