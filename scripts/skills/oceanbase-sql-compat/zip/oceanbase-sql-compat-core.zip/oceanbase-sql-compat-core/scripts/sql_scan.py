#!/usr/bin/env python3
"""Scan .sql files and produce a statement inventory for OceanBase compatibility analysis.

Usage:
    python sql_scan.py <file-or-dir> [...] [--format json|md] [-o OUTFILE]

What it does (deterministic pre-analysis; the agent does the semantic checks):
  * Splits files into statements (handles strings, comments, DELIMITER, PL blocks).
  * Classifies each statement: DDL / DML / DQL / TCL / DCL / SESSION / PL / OTHER.
  * Extracts optimizer hints (/*+ ... */) without discarding them.
  * Guesses the source dialect per file from lexical markers.
  * Emits JSON (machine-readable) or a Markdown inventory table.
"""
import argparse
import json
import os
import re
import sys

DDL = {"create", "alter", "drop", "truncate", "rename", "flashback", "purge"}
DML = {"insert", "update", "delete", "merge", "replace", "call", "load"}
DQL = {"select", "with", "explain", "describe", "desc", "table", "values"}
TCL = {"commit", "rollback", "savepoint", "begin", "start", "set"}
DCL = {"grant", "revoke"}
SESSION = {"show", "use", "analyze", "optimize", "check", "checksum", "kill", "lock", "unlock", "prepare", "execute", "deallocate", "do", "handler", "install", "uninstall", "reset", "xa"}
PL = {"declare"}

DIALECT_MARKERS = [
    ("mysql", re.compile(r"(`[^`]+`)|\bauto_increment\b|\bunsigned\b|\bengine\s*=|\bon\s+duplicate\s+key\b|\blimit\s+\d+\s*,\s*\d+", re.I)),
    ("oracle", re.compile(r"\bvarchar2\b|\bnumber\s*\(|\brownum\b|\bconnect\s+by\b|\bfrom\s+dual\b|\.\s*nextval\b|\.\s*currval\b|\bminus\b|\bstart\s+with\b|\bremark\s+on\b", re.I)),
    ("sqlserver", re.compile(r"\[\w+\]|\btop\s*\(\s*\d+\s*\)|\btop\s+\d+\b|\bidentity\s*\(|\bnvarchar\b|\bnolock\b|\bgo\s*$", re.I)),
    ("postgresql", re.compile(r"\bserial\b|\bbigserial\b|\breturning\b|::\s*\w+|\$\w*\$|\barray\s*\[|\bnow\(\)\s*-", re.I)),
    ("db2", re.compile(r"\bfetch\s+first\s+\d+\s+rows\s+only\b|\blong\s+varchar\b", re.I)),
]

HINT_RE = re.compile(r"/\*\+(.*?)\*/", re.S)
HINT_NAME_RE = re.compile(r"[A-Za-z_]+")


def strip_comments(sql, keep_hints=False):
    """Remove -- and /* */ comments. If keep_hints, /*+ */ and /*! ... */ survive."""
    out = []
    i, n = 0, len(sql)
    while i < n:
        ch = sql[i]
        if ch in "'\"`":
            q = ch
            out.append(ch)
            i += 1
            while i < n:
                out.append(sql[i])
                if sql[i] == "\\" and q != "`":
                    if i + 1 < n:
                        out.append(sql[i + 1])
                    i += 2
                    continue
                if sql[i] == q:
                    if q != "`" and i + 1 < n and sql[i + 1] == q:  # doubled quote
                        out.append(sql[i + 1])
                        i += 2
                        continue
                    i += 1
                    break
                i += 1
        elif sql.startswith("--", i) and (i + 2 >= n or sql[i + 2] in " \t\r\n"):
            j = sql.find("\n", i)
            i = n if j == -1 else j
        elif sql.startswith("#", i):
            j = sql.find("\n", i)
            i = n if j == -1 else j
        elif sql.startswith("/*", i):
            j = sql.find("*/", i + 2)
            j = n if j == -1 else j + 2
            seg = sql[i:j]
            if keep_hints and (seg.startswith("/*+") or seg.startswith("/*!")):
                out.append(seg)
            i = j
        else:
            out.append(ch)
            i += 1
    return "".join(out)


def split_statements(text):
    """Split SQL text into statements, honoring DELIMITER and PL/SQL blocks."""
    stmts = []
    lines = text.splitlines(keepends=True)
    delimiter = ";"
    buf = ""
    in_pl = False
    for line in lines:
        m = re.match(r"\s*DELIMITER\s+(\S+)", line, re.I)
        if m:
            delimiter = m.group(1)
            continue
        buf += line
        stripped = strip_comments(buf, keep_hints=True)
        first = re.match(r"\s*([A-Za-z]+)", stripped or "")
        kw = first.group(1).lower() if first else ""
        if kw in ("create", "begin", "declare") and re.search(
            r"\b(procedure|function|trigger|package|type)\b", stripped[:200], re.I
        ) or (kw in ("begin", "declare")):
            in_pl = True
        done = False
        if in_pl and re.match(r"\s*/\s*$", line):  # Oracle-style terminator
            done = True
            buf = buf.rstrip()[:-1]
        elif buf.rstrip().endswith(delimiter):
            if not in_pl:
                done = True
                buf = buf.rstrip()[: -len(delimiter)]
            else:
                # inside PL: only finish at delimiter following END (MySQL style)
                if re.search(r"\bend\s*" + re.escape(delimiter) + r"\s*$", buf.rstrip(), re.I):
                    done = True
                    buf = buf.rstrip()[: -len(delimiter)]
                    in_pl = False
        if in_pl and kw not in ("create", "begin", "declare") and re.match(r"\s*/\s*$", line):
            in_pl = False
        if done:
            stmt = buf.strip()
            if stmt:
                stmts.append(stmt)
            buf = ""
            in_pl = False
    tail = buf.strip()
    if tail and tail != "/":
        stmts.append(tail)
    return [s for s in stmts if s.strip() not in ("", "/")]


def classify(stmt):
    s = strip_comments(stmt).strip()
    m = re.match(r"([A-Za-z]+)(?:\s+([A-Za-z]+))?", s)
    if not m:
        return "OTHER"
    k1 = (m.group(1) or "").lower()
    k2 = (m.group(2) or "").lower()
    if k1 == "start":
        return "TCL"
    if k1 == "set":
        return "SESSION" if k2 not in ("transaction",) else "TCL"
    if k1 in DDL:
        return "DDL"
    if k1 in DML:
        return "DML"
    if k1 in DQL:
        return "DQL"
    if k1 in TCL:
        return "TCL"
    if k1 in DCL:
        return "DCL"
    if k1 in SESSION:
        return "SESSION"
    if k1 in PL or k1 == "begin":
        return "PL"
    return "OTHER"


def extract_hints(stmt):
    """Return hint names only (arguments inside parentheses are dropped)."""
    hints = []
    for body in HINT_RE.findall(stmt):
        no_args = re.sub(r"\([^()]*\)", " ", body)
        for name in HINT_NAME_RE.findall(no_args):
            if name.upper() not in ("ORACLE", "MYSQL"):
                hints.append(name.upper())
    return hints


def guess_dialect(full_text):
    scores = {}
    for name, rx in DIALECT_MARKERS:
        c = len(rx.findall(full_text))
        if c:
            scores[name] = c
    if not scores:
        return "unknown"
    return max(scores, key=scores.get)


def scan_file(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            text = f.read()
    except UnicodeDecodeError:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            text = f.read()
    stmts = split_statements(text)
    items = []
    for i, st in enumerate(stmts, 1):
        snippet = re.sub(r"\s+", " ", strip_comments(st)).strip()[:120]
        items.append({
            "index": i,
            "type": classify(st),
            "hints": extract_hints(st),
            "preview": snippet,
        })
    return {
        "file": path,
        "suspected_dialect": guess_dialect(text),
        "statement_count": len(stmts),
        "statements": items,
    }


def main():
    ap = argparse.ArgumentParser(description="Inventory SQL statements for OceanBase compatibility analysis.")
    ap.add_argument("paths", nargs="+", help=".sql files or directories")
    ap.add_argument("--format", choices=["json", "md"], default="json")
    ap.add_argument("-o", "--output", help="write result to file")
    args = ap.parse_args()

    files = []
    for p in args.paths:
        if os.path.isdir(p):
            for root, _, names in os.walk(p):
                for n in sorted(names):
                    if n.lower().endswith(".sql"):
                        files.append(os.path.join(root, n))
        else:
            files.append(p)
    results = [scan_file(f) for f in files]

    if args.format == "json":
        out = json.dumps(results, ensure_ascii=False, indent=2)
    else:
        lines = ["# SQL Inventory", ""]
        for r in results:
            lines.append(f"## `{r['file']}` — suspected dialect: **{r['suspected_dialect']}**, {r['statement_count']} statements")
            lines.append("")
            lines.append("| # | Type | Hints | Preview |")
            lines.append("|---|------|-------|---------|")
            for s in r["statements"]:
                preview = s["preview"].replace("|", "\\|")
                lines.append(f"| {s['index']} | {s['type']} | {', '.join(s['hints']) or '-'} | {preview} |")
            lines.append("")
        out = "\n".join(lines)

    if args.output:
        with open(args.output, "w", encoding="utf-8") as f:
            f.write(out)
        print(f"written: {args.output}")
    else:
        print(out)


if __name__ == "__main__":
    main()
