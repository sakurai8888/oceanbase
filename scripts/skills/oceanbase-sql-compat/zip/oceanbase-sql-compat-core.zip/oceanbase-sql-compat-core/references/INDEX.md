# OceanBase 4.4.2 SQL Reference Index

Extracted from `oceanbase/oceanbase-doc` branch `V4.4.2` (commit f58367df84).
Both language trees have identical structure: `references/zh-CN/<section>/...` and `references/en-US/<section>/...`.
Use zh-CN for authoritative wording; use en-US when reporting in English. Image links in the docs are broken (text-only extraction) — ignore them.

All lookup work is grep-driven. Do NOT read whole directories; grep for the construct, then Read the 1–3 matching files.

## Section map (same for both languages)

| Section | Source in oceanbase-doc | Contents |
|---|---|---|
| `sql-syntax/100.system-tenants` | 500.sql-reference/100.sql-syntax/100.system-tenants | Sys-tenant-only SQL (resource units, tenants, servers) |
| `sql-syntax/200.common-tenant-of-mysql-mode` | …/200.common-tenant-of-mysql-mode | **MySQL mode**: basic elements (data types, literals, identifiers, annotations), operators, functions, queries & subqueries, all SQL statements (DDL+DML A–Z), DDL functions, pseudo columns |
| `sql-syntax/300.common-tenant-of-oracle-mode` | …/300.common-tenant-of-oracle-mode | **Oracle mode**: basic elements, operators, functions, expressions, conditions, queries & subqueries, all SQL statements, DDL functions, pseudo columns, and the full **hint reference** under `300.basic-elements-of-oracle-mode/600.annotation-of-oracle-mode/400.hint-of-oracle-mode` |
| `sql-specifications/` | 200.sql-specifications-and-practices | SQL writing specs, incl. `200.sql-writing-Specification/700.hint-usage-specification.md` |
| `pl-reference/200.pl-mysql` | 600.pl-reference/200.pl-mysql | PL in MySQL mode; **`1000.pl-system-package-mysql`** = DBMS_* / system packages |
| `pl-reference/300.pl-oracle` | 600.pl-reference/300.pl-oracle | PL/SQL in Oracle mode; **`1400.pl-system-package-oracle`** = Oracle-style packages (DBMS_OUTPUT, DBMS_SCHEDULER, UTL_*, …) |
| `system-views/300.system-view-of-sys-tenant` | 700.system-views/… | Sys tenant: `200.dictionary-view…`, `300.performance-view…` |
| `system-views/400.system-view-of-mysql-mode` | … | MySQL-mode views: DBA_*/oceanbase.DBA_OB_* dictionary views, GV$/$ performance views, information_schema |
| `system-views/500.system-view-of-oracle-mode` | … | Oracle-mode views: DBA_/ALL_/USER_*, GV$… |
| `configuration-items-and-system-variables/` | 800.configuration-items-and-system-variables | Tenant/cluster parameters and system variables (sql_mode, collation, nls_*, …) |
| `error-code/` | 900.error-code | OceanBase error codes (MySQL + Oracle mode) |
| `hints-and-plan-management/` | 1000.performance-tuning-guide/…/700.manage-execution-plans | Mode-neutral hint overview, plan binding, SPM |

## Finding things fast

Every statement doc is named `<nnn>.<statement>-of-<mysql|oracle>-mode.md`, e.g.:
- `sql-syntax/200.common-tenant-of-mysql-mode/600.sql-statement-of-mysql-mode/2600.create-table-of-mysql-mode.md`
- `sql-syntax/300.common-tenant-of-oracle-mode/900.sql-statement-of-oracle-mode/100.ddl-of-oracle-mode/…`

Grep recipes (run from the language root):

```bash
# exact statement syntax (MySQL mode, Chinese docs)
grep -rl "CREATE TABLE" sql-syntax/200.common-tenant-of-mysql-mode/600.sql-statement-of-mysql-mode/

# a function, both modes at once
grep -rli "^# DATE_TRUNC\|date_trunc" sql-syntax/*/400.functions-of-mysql-mode sql-syntax/*/500.functions-of-oracle-mode

# a hint (canonical list lives in oracle-mode docs; same syntax applies to MySQL mode)
grep -rli "USE_HASH" sql-syntax/300.common-tenant-of-oracle-mode/300.basic-elements-of-oracle-mode/600.annotation-of-oracle-mode/400.hint-of-oracle-mode/

# a DBMS package subprogram
grep -rli "DBMS_SCHEDULER.CREATE_JOB\|create_job" pl-reference/

# a system view (name is unique per mode)
grep -rli "DBA_OB_TABLE_STATISTICS\|GV\$OB_SERVERS" system-views/

# a system variable / tenant parameter
grep -rli "sql_mode\|ob_query_timeout" configuration-items-and-system-variables/

# an error code or message
grep -rli "ORA-01400\|error code 4012" error-code/
```

Each doc follows the same shape: front-matter table, `# <Name>`, 描述/Description, 语法/Syntax (railroad-style code block), 参数说明/Parameters, 示例/Examples, 相关文档/Related. The Syntax block is the compatibility contract — quote it in reports when flagging a difference.

## Mode cheat-sheet

- OceanBase has two tenant modes: **MySQL mode** and **Oracle mode**. A statement can be valid in one and invalid in the other. Always settle the target mode before judging compatibility.
- MySQL mode ≈ MySQL 5.7/8.0 syntax superset + OceanBase extensions (partition options, tablegroup, `/*+ */` hints, sequences, etc.).
- Oracle mode ≈ Oracle 11g/12c SQL subset: VARCHAR2/NUMBER, DUAL, ROWNUM, CONNECT BY, sequences, PL/SQL packages. Outer join `(+)`, `START WITH … CONNECT BY` supported.
- Hints: `/*+ HINT_NAME */` syntax is shared; the canonical per-hint list is in oracle-mode hint docs; MySQL-mode usage overview is in `hints-and-plan-management/100.optimizer-hint.md`.
