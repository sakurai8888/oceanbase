---
name: oceanbase-sql-compat-core
description: Analyze SQL files and SQL text for OceanBase 4.4.2 compatibility, classify statements, convert foreign-dialect SQL, and produce evidence-based reports. Use together with the topic-specific oceanbase-* reference skills when you need detailed docs for a particular area.
type: prompt
whenToUse: When the user provides .sql files or SQL text and asks whether it runs on OceanBase, asks to migrate/convert/translate SQL to OceanBase, or asks about general compatibility, error codes, hints, or SQL writing specifications.
---

# OceanBase SQL Compatibility Analysis & Conversion

Ground every verdict in the bundled OceanBase 4.4.2 docs. Never rely on generic MySQL/Oracle knowledge alone — OceanBase differs from both.

## Resources in this skill

- `references/INDEX.md` — section map, directory conventions, grep recipes (covers the full doc tree).
- `references/sql-specifications/` — SQL writing specs and best practices.
- `references/hints-and-plan-management/` — mode-neutral hint overview, plan binding, SPM.
- `references/error-code/` — OceanBase error codes for MySQL and Oracle modes.
- `references/zh-CN/sql-syntax/300.common-tenant-of-oracle-mode/300.basic-elements-of-oracle-mode/600.annotation-of-oracle-mode/400.hint-of-oracle-mode` — canonical per-hint reference.
- `scripts/sql_scan.py` — deterministic inventory of SQL files (statement split, DDL/DML/DQL/TCL/DCL classification, hint extraction, source-dialect guess).

## Workflow

### 1. Intake and inventory

- Accept .sql files, directories, or pasted SQL (save pasted SQL to a temp .sql file first).
- Run `python scripts/sql_scan.py <paths> --format json` to get the statement inventory. For large dumps (>500 statements), process per file and group by statement type.
- Read the actual statements yourself; the inventory is an index, not the analysis.

### 2. Settle the target mode

OceanBase tenants are **MySQL mode** or **Oracle mode**; a statement can be valid in one and invalid in the other.

- If the user names the mode, use it.
- Else infer from the inventory's `suspected_dialect` and constructs (backticks/AUTO_INCREMENT → MySQL mode; VARCHAR2/DUAL/CONNECT BY → Oracle mode).
- If still ambiguous, ask the user.

### 3. Verify each statement against the docs

For every statement (or every distinct pattern when statements repeat), check the matching doc(s):

1. **Statement syntax** — load the appropriate topic skill (`oceanbase-sql-mysql-statements` or `oceanbase-sql-oracle-statements`) and grep for the statement doc.
2. **Data types, functions, operators, pseudo columns** — load `oceanbase-sql-mysql-functions-elements` or `oceanbase-sql-oracle-functions-elements`.
3. **Hints** — use the bundled hint docs and the canonical Oracle-mode hint list.
4. **PL and packages** — load `oceanbase-pl-mysql`, `oceanbase-pl-oracle-language`, or `oceanbase-pl-oracle-packages`.
5. **System views** — load the appropriate `oceanbase-views-*` skill.
6. **Session variables / config** — load `oceanbase-system-variables` or `oceanbase-config-items`.
7. **Known error scenarios** — use the bundled `error-code/` docs.

Classify each statement:

| Verdict | Meaning |
|---|---|
| ✅ SUPPORTED | Runs as-is in the target mode (doc evidence) |
| ⚠️ DIFFERENT | Runs but with behavioral/semantic differences worth flagging |
| 🔧 REWRITE | Not valid as-is; a documented OceanBase equivalent exists → convert |
| ❌ UNSUPPORTED | No documented equivalent in OceanBase 4.4.2 |
| ❓ UNVERIFIED | Docs are silent; say so — never guess |

Cite the doc file path for every non-✅ verdict.

### 4. Convert

- Rewrite minimally; preserve semantics over elegance. Comment each change inline (`-- [conv] reason`).
- Target the settled mode. If the source is Oracle-ish and the target is MySQL mode (or vice versa), say what the cross-mode conversion costs.
- Frequent conversions (verify each against the docs before applying):
  - SQL Server: `TOP (n)` → `LIMIT n`; `[name]` → backticks (MySQL) or double quotes (Oracle); `NVARCHAR` → `VARCHAR`; `WITH (NOLOCK)` → drop or document isolation choice.
  - PostgreSQL: `SERIAL` → `AUTO_INCREMENT` (MySQL) or sequence (Oracle); `RETURNING` → check doc support per mode; `::cast` → `CAST(x AS t)`; arrays → redesign.
  - Oracle → MySQL mode: `VARCHAR2` → `VARCHAR`; `NUMBER(p,s)` → `DECIMAL(p,s)`; `SYSDATE` → `NOW()`; `DUAL` → drop or keep; `ROWNUM` / `CONNECT BY` → check MySQL-mode docs.
  - MySQL → Oracle mode: backticks → double quotes + upper case; `AUTO_INCREMENT` → sequence; `ON DUPLICATE KEY UPDATE` → `MERGE INTO`.

### 5. Report

Write a Markdown report file (default `oceanbase-compat-report.md` next to the scanned files):

1. **Summary** — counts per verdict, target mode, doc version (4.4.2).
2. **Per-statement table** — file, #, type, verdict, issue, doc citation, converted SQL reference.
3. **Conversion log** — before → after for every 🔧.
4. **Blockers & risks** — ❌, ❓, ⚠️ items, required DBA actions.
5. **Converted SQL** — full converted scripts as separate `<name>.oceanbase.sql` files.

## Rules

- Version is pinned to **4.4.2**.
- A verdict without a doc citation is not a verdict.
- Analyze ALL statements, not a sample.
- Docs are bundled in sibling skills; if a topic is not in this skill, load the matching topic skill before judging.
