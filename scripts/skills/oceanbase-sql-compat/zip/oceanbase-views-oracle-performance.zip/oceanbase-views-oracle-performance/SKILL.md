---
name: oceanbase-views-oracle-performance
description: Look up OceanBase 4.4.2 Oracle-mode performance views (GV$/V$).
type: prompt
whenToUse: When the user asks about an Oracle-mode performance view in OceanBase.
---

# OceanBase Oracle-Mode Performance Views

Use the bundled docs to verify Oracle-mode performance views in OceanBase 4.4.2.

## Resources

- `system-views/500.system-view-of-oracle-mode/300.performance-view-of-oracle-mode/`

## How to use

1. Grep for the view name under both language trees.
2. Read the matching file to get column definitions and descriptions.
3. Cite the doc file path in your answer.
