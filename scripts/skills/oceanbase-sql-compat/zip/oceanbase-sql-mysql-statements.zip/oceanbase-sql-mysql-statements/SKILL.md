---
name: oceanbase-sql-mysql-statements
description: Look up OceanBase 4.4.2 MySQL-mode SQL statements (DDL, DML, DQL, DCL, TCL) and sys-tenant management commands.
type: prompt
whenToUse: When the user asks about the syntax or compatibility of a specific MySQL-mode SQL statement or sys-tenant command in OceanBase.
---

# OceanBase MySQL-Mode SQL Statements

Use the bundled docs to verify MySQL-mode SQL statement syntax in OceanBase 4.4.2.

## Resources

- `sql-syntax/200.common-tenant-of-mysql-mode/600.sql-statement-of-mysql-mode/` — all MySQL-mode statements.
- `sql-syntax/100.system-tenants/` — sys-tenant management commands (tenants, resource units/pools, etc.).

## How to use

1. Identify the statement name (e.g., CREATE TABLE, ALTER TABLE, INSERT, SELECT).
2. Grep for `<statement>-of-mysql-mode.md` in the statement directory.
3. Read the doc; compare its Syntax block against the user's SQL.
4. Classify as ✅ SUPPORTED, ⚠️ DIFFERENT, 🔧 REWRITE, ❌ UNSUPPORTED, or ❓ UNVERIFIED, with a doc citation.
5. For sys-tenant commands, grep under `sql-syntax/100.system-tenants/`.
