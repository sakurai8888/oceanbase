---
name: oceanbase-sql-mysql-functions-elements
description: Look up OceanBase 4.4.2 MySQL-mode data types, literals, identifiers, operators, functions, pseudo columns, queries/subqueries, and DDL functions.
type: prompt
whenToUse: When the user asks about MySQL-mode SQL functions, operators, data types, pseudo columns, query constructs, or DDL functions in OceanBase.
---

# OceanBase MySQL-Mode Functions & Language Elements

Use the bundled docs to verify MySQL-mode SQL language elements in OceanBase 4.4.2.

## Resources

- `sql-syntax/200.common-tenant-of-mysql-mode/100.basic-elements-of-mysql-mode/`
- `sql-syntax/200.common-tenant-of-mysql-mode/200.operator-of-mysql-mode/`
- `sql-syntax/200.common-tenant-of-mysql-mode/400.functions-of-mysql-mode/`
- `sql-syntax/200.common-tenant-of-mysql-mode/500.queries-and-subqueries-of-mysql-mode/`
- `sql-syntax/200.common-tenant-of-mysql-mode/700.ddl-function-of-mysql-mode/`
- `sql-syntax/200.common-tenant-of-mysql-mode/800.overview-of-pseudo-columns-of-mysql-mode/`

## How to use

1. Identify the construct: data type, function, operator, pseudo column, query clause, or DDL function.
2. Grep for the construct name in the matching subdirectory.
3. Read the doc; compare against the user's SQL. Note OceanBase-specific extensions or deviations from MySQL.
4. Cite the doc file path when flagging differences or unsupported behavior.
