---
name: oceanbase-pl-oracle-packages
description: Look up OceanBase 4.4.2 Oracle-mode PL system packages (DBMS_*, UTL_*, etc.) and label security packages.
type: prompt
whenToUse: When the user asks about an Oracle-mode DBMS/UTL package, its subprograms, or label security packages in OceanBase.
---

# OceanBase PL/Oracle Mode System Packages

Use the bundled docs to verify Oracle-mode PL system packages in OceanBase 4.4.2.

## Resources

- `pl-reference/300.pl-oracle/1300.pl-label-security-package-oracle/`
- `pl-reference/300.pl-oracle/1400.pl-system-package-oracle/`

## How to use

1. Identify the package and subprogram (e.g., DBMS_OUTPUT.PUT_LINE).
2. Grep for the package or subprogram name under both language trees.
3. Read the matching file(s) and verify signatures, parameters, and return types.
4. Cite the doc file path for any missing or incompatible subprogram.
