# Validation examples

Use these examples to calibrate verdicts and the exact-position requirement.
They are static OceanBase 4.4.2 documentation-review examples, not live-server
execution results. Object names are illustrative.

## 1. Documented INDEX hint

```sql
SELECT /*+ INDEX(ci idx_inv_client_date) */ invoice_id
FROM customer_invoices ci
WHERE ci.client_id = 1042;
```

| Statement | IsValid | NeedChange | Position | Change What |
|-----------|---------|------------|----------|-------------|
| 1 — SELECT with INDEX | Yes | No | N/A | N/A |

Object and index existence remain runtime prerequisites, not syntax changes.

## 2. Undocumented INDEX_DESC access-path hint

```sql
SELECT /*+ INDEX_DESC(o idx_orders_cust_date) */ order_id
FROM orders o;
```

| Statement | IsValid | NeedChange | Position | Change What |
|-----------|---------|------------|----------|-------------|
| 2 — SELECT with INDEX_DESC | No | Yes | `/*+ INDEX_DESC(o idx_orders_cust_date) */` → **`INDEX_DESC`** | Replace with a documented access-path strategy and verify the plan. Do not claim that `INDEX` preserves descending scan direction. |

## 3. Undocumented INDEX_FFS access-path hint

```sql
SELECT /*+ INDEX_FFS(ci idx_inv_client_date) */ invoice_id
FROM customer_invoices ci;
```

| Statement | IsValid | NeedChange | Position | Change What |
|-----------|---------|------------|----------|-------------|
| 3 — SELECT with INDEX_FFS | No | Yes | `/*+ INDEX_FFS(ci idx_inv_client_date) */` → **`INDEX_FFS`** | Use a documented access-path hint appropriate to the requirement and inspect the resulting plan. |

## 4. Oracle-style EXPLAIN PLAN FOR

```sql
EXPLAIN PLAN FOR
SELECT * FROM customer_invoices;
```

| Statement | IsValid | NeedChange | Position | Change What |
|-----------|---------|------------|----------|-------------|
| 4 — EXPLAIN | No | Yes | **`EXPLAIN PLAN FOR`** | Use `EXPLAIN SELECT * FROM customer_invoices;`, or the documented `EXPLAIN INTO ... SET STATEMENT_ID ...` form when using a dedicated plan table. |

## 5. Unsupported combined DBMS_XPLAN format

```sql
SELECT *
FROM TABLE(DBMS_XPLAN.DISPLAY(format => 'TYPICAL +HINT_REPORT'));
```

| Statement | IsValid | NeedChange | Position | Change What |
|-----------|---------|------------|----------|-------------|
| 5 — Plan display | No | Yes | `format => 'TYPICAL +HINT_REPORT'` → **`'TYPICAL +HINT_REPORT'`** | Use a documented format such as `BASIC`, `TYPICAL`, `ALL`, or `ADVANCED`; for example, `format => 'ALL'`. |

The named argument `format` is not the problem; the combined option value is.

## 6. Undocumented parallel-execution package

```sql
BEGIN
  DBMS_PARALLEL_EXECUTE.CREATE_TASK('TASK1');
END;
/
```

| Statement | IsValid | NeedChange | Position | Change What |
|-----------|---------|------------|----------|-------------|
| 6 — Anonymous block | No | Yes | **`DBMS_PARALLEL_EXECUTE.CREATE_TASK`** | Replace with a documented design, such as controlled `DBMS_SCHEDULER` jobs or serial/chunked processing. Preserve the intended chunking and concurrency requirements. |

## 7. Nested block comments

```sql
/* outer comment
   /* inner comment */
   outer comment */
SELECT 1 FROM DUAL;
```

| Statement | IsValid | NeedChange | Position | Change What |
|-----------|---------|------------|----------|-------------|
| 7 — Nested comment and SELECT | No | Yes | **`/* inner comment */` nested inside the outer block comment** | Remove nesting; use separate `/* ... */` comments or `--` line comments. |

## 8. Documented DBMS_STATS call

```sql
BEGIN
  DBMS_STATS.GATHER_TABLE_STATS(
    ownname => 'TEST',
    tabname => 'EMPLOYEES'
  );
END;
/
```

| Statement | IsValid | NeedChange | Position | Change What |
|-----------|---------|------------|----------|-------------|
| 8 — Anonymous block | Yes | No | N/A | N/A |

Statistics collection changes optimizer metadata. That operational effect does
not make the documented syntax invalid, but live testing belongs in an isolated
schema with appropriate privileges.

## 9. EXPLAIN INTO syntax versus prerequisites

```sql
EXPLAIN INTO invoice_plan_table
SET STATEMENT_ID = 'INV_TEST1'
SELECT invoice_id
FROM customer_invoices
WHERE client_id = 1042;
```

| Statement | IsValid | NeedChange | Position | Change What |
|-----------|---------|------------|----------|-------------|
| 9 — EXPLAIN INTO | Yes | No | N/A | N/A |

A suitable dedicated plan table and statement history are runtime prerequisites.
For the previously tested timestamp issue, the session setting was:

```sql
ALTER SESSION
SET NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH24:MI:SS.FF';
```

Do not misclassify a runtime plan-table or session-format error as a syntax
problem in the SELECT being explained.
