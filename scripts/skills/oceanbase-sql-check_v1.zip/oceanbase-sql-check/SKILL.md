---
name: oceanbase-sql-check
description: >-
  Review SQL compatibility against the pinned OceanBase 4.4.2 official
  documentation in Oracle or MySQL mode. Use for SELECT, INSERT, UPDATE,
  DELETE, REPLACE, MERGE, query hints, SQL functions, PL/SQL system packages,
  routine argument counts, argument names, options, EXPLAIN, and requests to
  identify or correct unsupported syntax. Trigger for "is this valid in
  OceanBase", "check this SQL", "OceanBase Oracle mode", "is this hint
  supported", "check this package call", and similar compatibility requests.
---

# OceanBase SQL Compatibility Checker

Review statements against the bundled OceanBase 4.4.2 reference catalogs.
Base compatibility claims on the official documentation, not generic Oracle or
MySQL behavior. Perform static documentation review unless live-server
execution is explicitly available and separately reported.

## Required workflow

1. Read [references/review-rules.md](references/review-rules.md) for every
   review. Apply its scope, result semantics, evidence wording, and safety
   rules.
2. Identify the OceanBase version, tenant mode, statement type, and every
   function, package routine, hint, and option that needs checking. Follow the
   mode-default rule in the review rules when the user omits the mode.
3. Read [references/official-sources.md](references/official-sources.md) when
   making source, coverage, version, or evidence-strength claims.
4. Search only the relevant catalogs before reading a larger section:
   - SELECT, functions, expressions, conversion: `select-catalog.sql`
   - INSERT, UPDATE, DELETE, REPLACE, MERGE: `dml-catalog.sql`
   - `DBMS_*`, `UTL_*`, `SA_*`, `ODCICONST`, `ANYDATA`, `XMLType`:
     `system-packages-catalog.sql`
   - Query hints: `query-hints.md`
5. Check the complete relevant section, including mode, syntax, parameter
   tables, defaults, options, restrictions, and examples. Search for synonyms
   and related forms before concluding that a feature is undocumented.
6. Compare each statement with the documented evidence. Check only syntax,
   functions, packages, argument counts, argument names, options, and hints
   unless the user explicitly expands the scope.
7. Return the required table from the review rules. Highlight the exact
   problematic token or fragment in `Position`; do not merely identify the
   statement or line.
8. Provide corrected SQL when requested or when it clarifies the required
   change. Preserve the user's business logic and distinguish a documented
   replacement from a semantic equivalent.
9. Use [references/validation-examples.md](references/validation-examples.md)
   to calibrate recurring findings and output wording.

## Search the references efficiently

Run the bundled helper from the skill directory. It uses only the Python
standard library and searches literal text case-insensitively by default.

```bash
# Find a hint and show its detailed section.
python3 scripts/search_reference.py INDEX_SS --reference hints --context 10

# Find a package routine and its signatures.
python3 scripts/search_reference.py DBMS_XPLAN.DISPLAY --reference packages --context 8

# Require both terms on the same matching line.
python3 scripts/search_reference.py GATHER_TABLE_STATS ownname --reference packages --context 6

# Search all catalogs for an EXPLAIN form.
python3 scripts/search_reference.py "EXPLAIN INTO" --context 5

# List the available reference keys and files.
python3 scripts/search_reference.py --list
```

Use `--regex` for a regular expression, `--case-sensitive` for exact case,
`--max-results` to change the result cap, and repeatable `--reference` options
to search several selected files. Do not load an entire multi-megabyte catalog
when targeted searches provide sufficient evidence.

## Evidence and correction rules

- Cite the pinned official source links already preserved in the catalogs.
- Say **documented** only when the pinned reference explicitly supports the
  interface or behavior.
- Say **example-only evidence** when a token appears in an official example
  without a dedicated interface definition.
- Say **not documented in the pinned 4.4.2 reference** rather than claiming
  that absence from documentation proves every runtime build must reject it.
- Treat malformed, unsupported, or conflicting hints carefully: OceanBase may
  ignore a hint instead of raising an error. Hint acceptance does not prove
  that the requested plan was used.
- Never invent a package, routine, parameter, hint, format option, or source.
- Never execute a complete catalog or a user's DML as part of the review.
- Do not describe static review as live execution. Recommend an isolated
  OceanBase 4.4.2 test and `EXPLAIN` when runtime confirmation is needed.

## Reference files

- [Review rules](references/review-rules.md): mandatory checking and output
  contract.
- [Official sources](references/official-sources.md): pinned revision,
  provenance, coverage, and evidence boundaries.
- [SELECT catalog](references/select-catalog.sql): documented SELECT forms,
  functions, expressions, conversion, hints, and curated combinations.
- [DML catalog](references/dml-catalog.sql): INSERT, UPDATE, DELETE, REPLACE,
  MERGE, related functions, hints, and expressions.
- [System-package catalog](references/system-packages-catalog.sql): documented
  package signatures, overloads, parameters, options, and restrictions.
- [Query-hint guide](references/query-hints.md): complete 137-entry guide with
  mode applicability, syntax, behavior, examples, and source links.
- [Validation examples](references/validation-examples.md): representative
  findings and expected table rows.

The catalogs are reference material, not deployment scripts. Select and test
only individual examples in an isolated environment when execution is needed.
