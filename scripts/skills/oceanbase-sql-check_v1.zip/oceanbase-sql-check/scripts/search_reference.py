#!/usr/bin/env python3
"""Search the bundled OceanBase reference files without loading them fully."""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

SKILL_ROOT = Path(__file__).resolve().parents[1]
REFERENCE_ROOT = SKILL_ROOT / "references"
REFERENCES = {
    "rules": REFERENCE_ROOT / "review-rules.md",
    "sources": REFERENCE_ROOT / "official-sources.md",
    "select": REFERENCE_ROOT / "select-catalog.sql",
    "dml": REFERENCE_ROOT / "dml-catalog.sql",
    "packages": REFERENCE_ROOT / "system-packages-catalog.sql",
    "hints": REFERENCE_ROOT / "query-hints.md",
    "examples": REFERENCE_ROOT / "validation-examples.md",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Search bundled OceanBase 4.4.2 references. Multiple literal terms "
            "must all occur on the same line unless --regex is used."
        )
    )
    parser.add_argument("terms", nargs="*", help="Literal terms or one regular expression")
    parser.add_argument(
        "--reference",
        action="append",
        choices=[*REFERENCES, "all"],
        help="Reference key to search; repeat to select several (default: all)",
    )
    parser.add_argument("--context", type=int, default=2, help="Context lines around matches (default: 2)")
    parser.add_argument("--max-results", type=int, default=20, help="Maximum matches (default: 20)")
    parser.add_argument("--regex", action="store_true", help="Interpret the joined terms as a regular expression")
    parser.add_argument("--case-sensitive", action="store_true", help="Use case-sensitive matching")
    parser.add_argument("--line-width", type=int, default=500, help="Clip displayed lines to this width (default: 500)")
    parser.add_argument("--list", action="store_true", help="List reference keys and exit")
    return parser.parse_args()


def selected_files(keys: list[str] | None) -> list[tuple[str, Path]]:
    if not keys or "all" in keys:
        return list(REFERENCES.items())
    return [(key, REFERENCES[key]) for key in dict.fromkeys(keys)]


def clipped(text: str, width: int) -> str:
    return text if len(text) <= width else text[: max(1, width - 1)] + "…"


def main() -> int:
    args = parse_args()

    if args.list:
        for key, path in REFERENCES.items():
            status = f"{path.stat().st_size:,} bytes" if path.is_file() else "MISSING"
            print(f"{key:8} references/{path.name} ({status})")
        return 0

    if not args.terms:
        print("Provide at least one search term, or use --list.", file=sys.stderr)
        return 2
    if not 0 <= args.context <= 20:
        print("--context must be between 0 and 20.", file=sys.stderr)
        return 2
    if not 1 <= args.max_results <= 200:
        print("--max-results must be between 1 and 200.", file=sys.stderr)
        return 2
    if args.line_width < 40:
        print("--line-width must be at least 40.", file=sys.stderr)
        return 2

    flags = 0 if args.case_sensitive else re.IGNORECASE
    pattern = None
    folded_terms: list[str] = []
    if args.regex:
        try:
            pattern = re.compile(" ".join(args.terms), flags)
        except re.error as exc:
            print(f"Invalid regular expression: {exc}", file=sys.stderr)
            return 2
    else:
        folded_terms = args.terms if args.case_sensitive else [term.casefold() for term in args.terms]

    shown = 0
    files_searched = 0
    for key, path in selected_files(args.reference):
        if shown >= args.max_results:
            break
        if not path.is_file():
            print(f"Missing reference: {path}", file=sys.stderr)
            continue

        files_searched += 1
        lines = path.read_text(encoding="utf-8").splitlines()
        for index, line in enumerate(lines):
            if pattern is not None:
                matched = pattern.search(line) is not None
            else:
                candidate = line if args.case_sensitive else line.casefold()
                matched = all(term in candidate for term in folded_terms)
            if not matched:
                continue

            shown += 1
            print(f"\n### {key}: references/{path.name}:{index + 1}")
            start = max(0, index - args.context)
            stop = min(len(lines), index + args.context + 1)
            for context_index in range(start, stop):
                marker = ">" if context_index == index else " "
                content = clipped(lines[context_index], args.line_width)
                print(f"{marker} {context_index + 1:>8} | {content}")
            if shown >= args.max_results:
                break

    if shown == 0:
        print("No matches found. Try a synonym, another reference, or a broader term.")
    else:
        suffix = " (result cap reached)" if shown >= args.max_results else ""
        print(f"\nShowing {shown} match(es) across {files_searched} searched file(s){suffix}.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
