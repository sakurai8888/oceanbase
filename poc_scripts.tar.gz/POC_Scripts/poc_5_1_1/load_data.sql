set global secure_file_priv='/';

TRUNCATE TABLE load_test;

LOAD DATA INFILE '/home/obadmin/POC_Scripts_prepare/poc_5_1_1/big_file.txt'
INTO TABLE load_test
FIELDS TERMINATED BY '|'
LINES TERMINATED BY '\n'
(log_prefix, @log_time, id, uuid, code_number, val)
SET log_time = TO_DATE(@log_time, 'YYYY-MM-DD HH24:MI:SS');

SELECT COUNT(*) FROM load_test;
