DROP TABLE load_test;

CREATE TABLE load_test(
  log_prefix VARCHAR2(20),
  log_time   DATE,
  id         INT,
  uuid       VARCHAR2(50),
  code_number NUMBER,
  val        NUMBER
);

select count(*) from load_test;
