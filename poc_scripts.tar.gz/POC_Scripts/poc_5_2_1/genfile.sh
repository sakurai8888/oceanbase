#!/bin/bash

awk 'BEGIN{
  srand(42);
  for(i=1;i<=1000000;i++){
    printf "P%06d|2026-10-%02d %02d:%02d:%02d|%d|uuid-%08d|%d|%.2f\n", \
      i%100, 1+int(rand()*10), int(rand()*24), int(rand()*60), int(rand()*60), \
      i, i, int(rand()*10000), rand()*1000
  }
}' > ./import/LOAD_TEST.dat
