select to_char(sysdate,'YYYY-MM-DD HH:Mi:ss') as CurrentTime from dual;

alter session set nls_date_format='YYYY-MM-DD HH24:Mi:ss';

select count(*) as "No. of Rows" from load_test;

select * from load_test where rownum <= 10;
